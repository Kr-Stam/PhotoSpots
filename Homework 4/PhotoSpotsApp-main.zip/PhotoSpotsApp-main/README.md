# PhotoSpotsApp
Run the docker container on 9090/locations
