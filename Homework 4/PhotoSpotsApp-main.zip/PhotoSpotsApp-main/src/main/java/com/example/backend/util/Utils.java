package com.example.backend.util;

public class Utils {
    public static long LocationId = 1;
    public static long UserId = 1;
}
