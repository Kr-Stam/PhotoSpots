package com.example.backend.Exceptions;

public class InvalidArgumentsException extends Exception{
    public InvalidArgumentsException() {
        super("Invalid arguments exception");
    }
}
