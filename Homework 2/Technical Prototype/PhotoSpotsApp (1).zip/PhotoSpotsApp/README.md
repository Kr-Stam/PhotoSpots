# PhotoSpots
This is a university project for the course Software Analysis and Design from Ss. Cyril and Methodius FCSE
