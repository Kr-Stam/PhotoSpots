In our database there is a list of 70 prominent locations(cities and municipalities) in Macedonia. 
Each row includes a city's latitude, longitude, id and other variables of interest. 
This is a subset of all 2,475 places in Macedonia (and only some of the fields) that can be found in World Cities Database. 
We're getting this data subset for free under an MIT license which is free to use for personal or commercial applications/projects.

This data is to be used as test data to populate our database.