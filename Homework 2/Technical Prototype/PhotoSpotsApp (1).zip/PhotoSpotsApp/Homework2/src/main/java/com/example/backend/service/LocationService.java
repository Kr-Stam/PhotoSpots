package com.example.backend.service;

import com.example.backend.model.Location;

import java.util.List;
import java.util.Optional;

public interface LocationService {
    List<Location> findAll();

    Optional<Location> findById(Long id);

    Optional<Location> findByName(String name);

    Optional<Location> save(String name, String image, double longitude, double latitude);

    Optional<Location> edit(String name, String image, double longitude, double latitude);

    void deleteById(Long id);

}
