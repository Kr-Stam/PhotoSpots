package com.example.backend.service;

public interface UserInterface {
}
