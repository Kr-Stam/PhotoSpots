package com.example.backend.model;

import lombok.Data;

import java.util.Random;

@Data
public class Location {

    private Long id;
    private String name;
    private String image;
    private double longitude;
    private double latitude;
    private int downvotes;
    private int upvotes;

//    private List<String> comments;

    public Location(String name, String image, double longitude, double latitude) {
        Random random = new Random();
        id = random.nextLong(1000);
        this.name = name;
        this.image = image;
        this.longitude = longitude;
        this.latitude = latitude;
        downvotes = 0;
        upvotes = 0;
    }
}
