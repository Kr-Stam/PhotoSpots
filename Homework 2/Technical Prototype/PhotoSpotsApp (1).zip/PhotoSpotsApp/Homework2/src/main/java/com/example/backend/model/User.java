package com.example.backend.model;


import lombok.Data;

import java.util.Random;

@Data
public class User {

    private Long id;
    private String email;
    private String username;

    private String password;
//    private List<PhotoSpot> spots;


    public User(String email, String username, String password) {
        Random random = new Random();
        id = random.nextLong(1000);
        this.email = email;
        this.username = username;
        this.password = password;
    }
}
